import concurrent.futures,json,pathlib,subprocess,time,urllib.request
root=pathlib.Path('/root/apm-load-15qps-20260925-0456');deadline=time.monotonic()+21600
origin='https://enhance-pir.valargroup.dev'
def init_load():
    while time.monotonic()<deadline:
        start=time.monotonic()
        try:
            with urllib.request.urlopen(origin+'/v1/enhance/init',timeout=10) as r:r.read()
        except Exception as e:
            with (root/'init-errors.log').open('a') as f:f.write(str(e)+'\n')
        time.sleep(max(0,1-(time.monotonic()-start)))
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
    pool.submit(init_load)
    n=0
    while time.monotonic()<deadline:
        n+=1
        remaining=int(deadline-time.monotonic())
        if remaining<=0:break
        report=root/f'load-{n:02d}.json'
        command=['/root/architecture2-deploy/architecture2-load','--server',origin,'--oracle','/root/architecture2-deploy/public-oracle.json','--parallelism','8','--rate','15','--duration',f'{min(60,remaining)}s','--warmup','0s','--max-error-rate','0','--json-out',str(report)]
        try:
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=min(120,remaining+15))
        except subprocess.TimeoutExpired:
            print(json.dumps({"batch":n,"error":"load subprocess timed out"}),flush=True)
            continue
        with (root/'load.log').open('a') as f:f.write(result.stdout+'\n')
        print(json.dumps({'batch':n,'exit':result.returncode,'report':str(report)}),flush=True)
