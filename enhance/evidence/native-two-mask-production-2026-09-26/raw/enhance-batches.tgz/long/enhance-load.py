import datetime,json,pathlib,subprocess,threading,time,urllib.request
root=pathlib.Path("/root/native2m-dc0355b-validation/long/enhance");root.mkdir(parents=True,exist_ok=True)
origin="https://enhance-pir.valargroup.dev"
binary="/opt/enhance-pir/releases/native2m-dc0355b/enhance-pir-load-test"
deadline=time.time()+6*3600
stop=threading.Event()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def background():
    n=0
    while time.time()<deadline and not stop.is_set():
        started=time.time();sample={"utc":utc()}
        urls={"init":origin+"/v1/enhance/init"}
        if n%15==0:urls.update({"router_metrics":"http://10.142.0.14:8093/internal/metrics","router_health":"http://10.142.0.14:8093/internal/health","coordinator_metrics":"http://127.0.0.1:8080/metrics","ingress_metrics":"http://127.0.0.1:8083/internal/metrics","worker15":"http://10.142.0.15:8091/internal/metrics","worker16":"http://10.142.0.16:8091/internal/metrics","gpu":"http://10.250.90.3:8091/internal/metrics"})
        for name,url in urls.items():
            try:
                with urllib.request.urlopen(url,timeout=5) as r:body=r.read().decode()
                if name=="init":sample["init_generation"]=json.loads(body).get("generation")
                else:sample[name]=body
            except Exception as e:sample[name+"_error"]=str(e)
        with (root/"samples.jsonl").open("a") as f:f.write(json.dumps(sample)+"\n")
        n+=1;stop.wait(max(0,1-(time.time()-started)))
t=threading.Thread(target=background);t.start()
try:
    n=0
    while time.time()<deadline:
        n+=1;duration=min(60,int(deadline-time.time()))
        if duration<=5:break
        began=utc();report=root/f"load-{n:04d}.json"
        cmd=[binary,"--server",origin,"--oracle","/root/architecture2-deploy/public-oracle.json","--parallelism","8","--rate","20","--duration",f"{duration}s","--warmup","0s","--max-error-rate","0","--json-out",str(report)]
        try:
            r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=duration+60)
            with (root/"load.log").open("a") as f:f.write(r.stdout+"\n")
            status={"batch":n,"utc_start":began,"utc_end":utc(),"exit":r.returncode,"report":str(report)}
        except subprocess.TimeoutExpired:status={"batch":n,"utc_start":began,"exit":124,"error":"timeout"}
        with (root/"batches.jsonl").open("a") as f:f.write(json.dumps(status)+"\n")
finally:stop.set();t.join()
