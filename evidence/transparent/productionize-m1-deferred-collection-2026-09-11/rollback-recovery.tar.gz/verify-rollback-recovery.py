import asyncio, importlib.util, json, subprocess, time
from pathlib import Path
root = Path('/opt/transparent-publisher-build/defer-collection-v2-20260911')
spec = importlib.util.spec_from_file_location('upgrade', root/'ops/scripts/upgrade-transparent-fleet.py')
U = importlib.util.module_from_spec(spec)
spec.loader.exec_module(U)
saved = root/'rollout/fleet-upgrade'
out = root/'rollback-recovery'
async def main():
    state = subprocess.check_output(['systemctl','show','transparent-m1-defer-collection-rollout.service','-p','MainPID','--value'],text=True).strip()
    if state != '0': raise RuntimeError('original supervisor is still live')
    out.mkdir(exist_ok=False)
    fleet = U.L.Fleet(json.loads(Path('/opt/transparent-publisher/fleet.json').read_text()))
    before = json.loads((saved/'deployment.json').read_text())['before']
    deadline = time.monotonic()+1800
    services = ('transparent-replica-reconciler','transparent-publish-controller')
    while time.monotonic()<deadline:
        try:
            await U.ready_to_freeze(fleet, fleet.roster)
            U.service('stop', *services)
            evidence = await U.verify_workers(fleet, fleet.roster, before, str(root/'artifacts/soak-query'), '/srv/zakura/transparent-publications')
            U.L.atomic_json(out/'verified.json',evidence)
            await U.start_authority()
            await U.reopen(fleet,saved)
            await U.verify_public(fleet)
            U.L.atomic_json(out/'result.json',{'passed':True,'scope':'rollback recovery only'})
            return
        except Exception as error:
            print(type(error).__name__+': '+str(error),flush=True)
        finally:
            U.service('start', *services)
        await asyncio.sleep(5)
    raise RuntimeError('recovery verification timed out')
asyncio.run(main())
