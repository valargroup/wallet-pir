import datetime,hashlib,json,pathlib,subprocess,urllib.request,os
root=pathlib.Path('/opt/transparent-publisher-build/storage-policy-20260911')
release=pathlib.Path('/opt/transparent-publisher-build/shoup-release-20260911')
source='2c4a2507523a39e76aef8a6db3076c40d54026ae'
ops='864f7417719dcde7df12fc3ed63ead50ba0c8231'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
manifest=json.loads((root/'source-manifest.json').read_text());assert manifest['operations_source_sha']==ops
for n,d in manifest['files'].items():assert sha(root/n)==d,n
artifacts=json.loads((release/'artifact-sha256.json').read_text())
for n,d in artifacts.items():assert sha(root/'artifacts'/n)==d,n
assert json.loads((release/'source-commit.json').read_text())['source_sha']==source
assert not subprocess.check_output(['systemctl','list-units','--state=running','--no-legend','transparent*rollout*'],text=True).strip()
configpath=pathlib.Path('/opt/transparent-publisher/fleet.json')
assert sha(configpath)=='ad6048bd12d3472fa5a9632ff275544b360e9509334ddc0a7934580fae22015f'
assert sha('/usr/local/bin/transparent-publish-controller')=='b191c25abb027378b564d32d62c23c3aee52c300b5506cc0ab259cde57eddcf4'
assert sha('/opt/transparent-publisher/controller.json')=='5ce43599786b177bb26bfdb991ae07eafa880855294c8053a0fada38d73c7da3'
assert sha('/opt/transparent-publisher/transparent-live-fleet.py')==sha(root/'ops/scripts/transparent-live-fleet.py')
config=json.loads(configpath.read_text());roster=json.loads(pathlib.Path(config['roster']).read_text())
ssh=['ssh','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2','-i','/opt/transparent-publisher/credentials/deploy-ssh','-o','UserKnownHostsFile=/opt/transparent-publisher/credentials/known_hosts']
def remote(host,cmd,data=None):
 return subprocess.check_output(ssh+['root@'+host,cmd],input=data,timeout=60)
preflight={}
helper=(root/'ops/scripts/transparent-storage-policy.py').read_bytes()
for worker in roster:
 host=worker['ssh_host']
 remote(host,'cat > /tmp/transparent-storage-policy-864f741.py',helper)
 value=json.loads(remote(host,'python3 /tmp/transparent-storage-policy-864f741.py --preflight'))
 assert value['helper_sha256']==hashlib.sha256(helper).hexdigest()
 preflight[worker['id']]=value
# Close the successful temporary experiment before capturing the durable rollout predecessor.
# The completed transient timer may have been garbage-collected by systemd.
assert remote('10.142.0.10','systemctl show transparent-m1-discard-restore.timer -p ActiveState --value').decode().strip() == 'inactive'
trial=remote('10.142.0.10','findmnt -n -o OPTIONS /').decode().strip()
assert 'discard' in trial.split(','),trial
with urllib.request.urlopen('http://10.142.0.10:8093/v1/ready',timeout=5) as r:ready=json.load(r)
assert ready['binary_sha256']==artifacts['transparent-shard-server'] and ready['ready']
(root/'fleet-before-storage.json').write_bytes(configpath.read_bytes())
config['storage_nodiscard']=True
encoded=(json.dumps(config,indent=2)+'\n').encode()
with configpath.with_suffix('.storage-next').open('wb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
os.replace(configpath.with_suffix('.storage-next'),configpath)
fd=os.open(configpath.parent,os.O_RDONLY);os.fsync(fd);os.close(fd)
(root/'rollout-preflight.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_source_sha':source,'operations_source_sha':ops,'artifacts':artifacts,'worker_preflights':preflight,'restored_trial_options':trial,'new_fleet_config_sha256':sha(configpath),'predecessor':ready},indent=2)+'\n')
subprocess.run(['systemd-run','--unit=transparent-m1-storage-policy-rollout','--property=Restart=no','/usr/bin/python3',str(root/'ops/scripts/run-transparent-hardening-rollout.py'),'--artifacts',str(root/'artifacts'),'--source-sha',source,'--out',str(root/'rollout')],check=True)
