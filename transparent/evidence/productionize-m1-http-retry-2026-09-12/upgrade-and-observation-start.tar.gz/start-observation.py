import asyncio
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import urllib.request

ROOT = Path('/opt/transparent-publisher-build/caddy-http-retry-20260912')
UPGRADE = Path('/opt/transparent-publisher-build/archive-cache-upgrade-20260911')
OLD = Path('/opt/transparent-publisher-build/defer-collection-v2-20260911')
OUT = ROOT/'observation'
BINARY = '200ca85065c8096d344749d5e51a2db569ec369c71bd2ffff8cf0e9fd014ff62'
SOURCE = 'a5f79ed760e458b873b5382a1e4243dda632d1f7'
CONFIG = Path('/opt/transparent-publisher/fleet.json')
SPEC = importlib.util.spec_from_file_location('rollout', ROOT/'ops/scripts/run-transparent-hardening-rollout.py')
R = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(R)

async def main():
    router = json.loads((ROOT/'router-upgrade/result.json').read_text())
    assert router['passed'] and router['binary_sha256'] == 'b7105518e3ed1c0761f232e44fc09345535533c9cb0abf0e12809416c7ac64d9'
    config = json.loads(CONFIG.read_text())
    roster = json.loads(Path(config['roster']).read_text())
    ids = {w['id'] for w in roster}
    upgrade = json.loads((UPGRADE/'upgrade/result.json').read_text())
    canary = json.loads((OLD/'rollout/canary/result.json').read_text())
    assert len(ids) == 6 and set(upgrade['workers']) == ids
    assert upgrade['passed'] and upgrade['binary_sha256'] == BINARY
    assert canary['passed'] and canary['binary_sha256'] == BINARY
    assert hashlib.sha256((OLD/'artifacts/transparent-shard-server').read_bytes()).hexdigest() == BINARY
    assert {w for w in ids if '-recent-' in w} <= set(config['managed_recent_workers'])
    ready = {}
    for worker in roster:
        with urllib.request.urlopen('http://'+worker['upstream']+'/v1/ready', timeout=10) as response:
            value = json.load(response)
        assert value['ready'] and value['binary_sha256'] == BINARY, worker['id']
        ready[worker['id']] = value
    OUT.mkdir(exist_ok=False)
    provenance = dict(source_sha=SOURCE, binary_sha256=BINARY, operations_commit='0e2c003', router_binary_sha256='b7105518e3ed1c0761f232e44fc09345535533c9cb0abf0e12809416c7ac64d9', monitor_sha256=hashlib.sha256((ROOT/'ops/scripts/observe-transparent-hardening.py').read_bytes()).hexdigest(),
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        canary_result=str(OLD/'rollout/canary/result.json'), upgrade_result=str(UPGRADE/'upgrade/result.json'),
        fleet_config_sha256=hashlib.sha256(CONFIG.read_bytes()).hexdigest(),
        roster_sha256=hashlib.sha256(Path(config['roster']).read_bytes()).hexdigest(),
        maintenance_restoration='Existing Sep 12 restoration remains scheduled; no gate exemptions')
    (OUT/'provenance.json').write_text(json.dumps(provenance, indent=2)+'\n')
    (OUT/'initial-ready.json').write_text(json.dumps(ready, indent=2)+'\n')
    def status(phase, **extra):
        value = dict(phase=phase, **provenance, **extra)
        (OUT/'status.next').write_text(json.dumps(value, indent=2)+'\n')
        (OUT/'status.next').replace(OUT/'status.json')
        print(json.dumps(value), flush=True)
    monitor = [sys.executable, ROOT/'ops/scripts/observe-transparent-hardening.py',
        '--fleet-config', CONFIG, '--fleet-script', ROOT/'ops/scripts/transparent-live-fleet.py',
        '--binary-sha256', BINARY, '--freshness-seconds', '30', '--replica-freshness-seconds', '60']
    status('fleet_observation')
    try:
        async with asyncio.TaskGroup() as group:
            for worker in roster:
                wid = worker['id']
                load = ['--query-binary', OLD/'artifacts/soak-query'] if wid == 'transparent-pir-recent-01' else []
                group.create_task(R.command(monitor+['--worker', wid, '--seconds', '86400', '--blocks', '300',
                    '--out', OUT/('fleet-'+wid)]+load, OUT/('fleet-'+wid+'.log')))
        results = {wid: json.loads((OUT/('fleet-'+wid)/'result.json').read_text()) for wid in ids}
        assert all(r['passed'] and r['binary_sha256'] == BINARY and r['seconds'] >= 86400 and min(r['blocks'], r['replica_blocks']) >= 300 for r in results.values())
        status('complete', results=results)
    except BaseException as error:
        status('failed', error=repr(error))
        raise

asyncio.run(main())
