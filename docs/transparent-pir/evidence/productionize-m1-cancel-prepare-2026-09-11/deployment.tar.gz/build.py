import hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('/opt/transparent-publisher-build/cancel-prepare-20260911');os.chdir(root)
for name,digest in json.loads(Path('source-manifest.json').read_text()).items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
artifacts=root/'artifacts';artifacts.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR='/opt/transparent-publisher-build/6e0c65c/target',RUSTFLAGS='-C target-cpu=x86-64-v3 -C target-feature=+pclmulqdq',CARGO_BUILD_JOBS='2')
def build(name,args):
 with open(name+'.jsonl','w') as out:
  subprocess.run(['/root/.cargo/bin/cargo']+args+['--message-format=json'],stdout=out,env=env,check=True)
 return [json.loads(line) for line in Path(name+'.jsonl').read_text().splitlines() if line.startswith('{')]
rows=build('controller-tests',['test','--locked','--release','-p','transparent-filter-server','--lib','--no-run'])
for row in rows:
 if row.get('executable') and row['profile'].get('test'):
  shutil.copy2(row['executable'],artifacts/'controller-tests')
with open('linux-controller-tests.log','w') as out:
 subprocess.run([str(artifacts/'controller-tests'),'controller::tests','--nocapture'],stdout=out,stderr=subprocess.STDOUT,check=True)
rows=build('controller',['build','--locked','--release','-p','transparent-filter-server','--bin','transparent-publish-controller'])
for row in rows:
 if row.get('executable'):shutil.copy2(row['executable'],artifacts/row['target']['name'])
(root/'artifact-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts.iterdir()},indent=2)+'\n')
print('Linux controller build and tests passed',flush=True)
