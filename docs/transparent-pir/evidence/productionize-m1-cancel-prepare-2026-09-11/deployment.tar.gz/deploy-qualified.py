import asyncio,datetime,hashlib,importlib.util,json,os,shutil,subprocess,time,urllib.request
from pathlib import Path
root=Path('/opt/transparent-publisher-build/cancel-prepare-20260911')
live=Path('/opt/transparent-publisher')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def unit(name):return subprocess.check_output(['systemctl','show',name,'-p','MainPID','-p','ActiveState','-p','ExecMainStatus'],text=True)
assert 'ActiveState=inactive' in unit('transparent-m1-cancel-prepare-build.service')
assert 'ExecMainStatus=0' in unit('transparent-m1-cancel-prepare-build.service')
assert not subprocess.check_output(['systemctl','list-units','--state=running','--no-legend','transparent*rollout*'],text=True).strip()
for name,digest in json.loads((root/'source-manifest.json').read_text()).items():assert sha(root/name)==digest,name
assert json.loads((root/'source-commit.json').read_text())['source_sha']=='4a23670addfe52bfc15a0eccff86bb68ceb982a9'
artifacts=root/'artifacts'
for name,digest in json.loads((root/'artifact-sha256.json').read_text()).items():assert sha(artifacts/name)==digest,name
binary=Path('/usr/local/bin/transparent-publish-controller');script=live/'transparent-live-fleet.py';config=live/'controller.json'
assert sha(binary)=='b191c25abb027378b564d32d62c23c3aee52c300b5506cc0ab259cde57eddcf4'
assert sha(script)=='75186ce5c7e5d8bb0e2f33a667192a136657623fe2ea5cbe5df8cffa6aa27b63'
assert sha(config)=='5ce43599786b177bb26bfdb991ae07eafa880855294c8053a0fada38d73c7da3'
assert sha(live/'fleet.json')=='c844b3a1e04fc22a0ee95cfd49174e3bf35e8d848eb5a1069254b7ef8675c7fe'
assert sha(script)==sha(root/'ops/scripts/transparent-live-fleet.py')
assert json.loads((live/'fleet.json').read_text())['storage_nodiscard'] is True
assert json.loads(Path('/opt/transparent-publisher-build/shoup-release-20260911/source-commit.json').read_text())['source_sha']=='2c4a2507523a39e76aef8a6db3076c40d54026ae'
backup=root/'deployment-backup';backup.mkdir()
for p in [binary,config]:shutil.copy2(p,backup/p.name)
expected={'transparent-shard-server':'cc6dabbd03ea2b1bccbe2d92d547e10bb9433e1d96215b7cd240c03dab9c8ec9','soak-query':'209a46565aee21b184e5cc71fb90487f16e753f78684bc46cf751b58de5dfeab','shard-control':'d8eebd1d5d7e0a4d06a9246d851c6b41f1056fe4effdc258bdf62a820219a45d'}
for name,digest in expected.items():
 p=Path('/opt/transparent-publisher-build/shoup-release-20260911/artifacts')/name
 assert sha(p)==digest
 shutil.copy2(p,artifacts/name)
def replace(source,target):
 temporary=target.with_name(target.name+'.unpublished-next')
 shutil.copy2(source,temporary);os.replace(temporary,target)
spec=importlib.util.spec_from_file_location('fleet',root/'ops/scripts/transparent-live-fleet.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def fetch(url):
 with urllib.request.urlopen(url,timeout=5) as response:return json.load(response)
record={'source_sha':'4a23670addfe52bfc15a0eccff86bb68ceb982a9','worker_source_sha':'2c4a2507523a39e76aef8a6db3076c40d54026ae','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':{p.name:sha(p) for p in [binary,script,config]},'worker_binary_sha256':expected['transparent-shard-server'],'fleet_config_sha256':sha(live/'fleet.json')}
(root/'deployment-start.json').write_text(json.dumps(record,indent=2)+'\n')
services=['transparent-publish-controller']
try:
 subprocess.run(['systemctl','stop',*services],check=True)
 replace(artifacts/'transparent-publish-controller',binary)
 value=json.loads(config.read_text());value['source_sha']='4a23670addfe52bfc15a0eccff86bb68ceb982a9'
 next_config=root/'controller-next.json';next_config.write_text(json.dumps(value,indent=2)+'\n');next_config.chmod(config.stat().st_mode & 0o777)
 replace(next_config,config)
 subprocess.run(['systemctl','start','transparent-publish-controller'],check=True)
 deadline=time.monotonic()+300
 while True:
  try:
   status=fetch('http://127.0.0.1:8094/v1/status')
   ready=fetch('http://10.142.0.10:8093/v1/ready')
   first=fetch('https://transparent-pir.valargroup.dev/v1/shards')
   second=fetch('https://enhance-pir.valargroup.dev/v1/filters/shards')
   assert first==second
   fleet=module.Fleet(json.loads((live/'fleet.json').read_text()))
   assert asyncio.run(fleet.node_height())==status['public_height']
   assert asyncio.run(fleet.canonical_hash(status['public_height']))==status['public_hash']
   assert first['shards'][-1]['end_height']==status['public_height']
   assert first['shards'][-1]['terminal_block_hash']==status['public_hash']
   assert status['phase']=='serving' and ready['ready'] and ready['map_sha256']==status['map_sha256']
   assert ready['binary_sha256']==expected['transparent-shard-server']
   break
  except Exception as e:
   if time.monotonic()>=deadline:raise
   print('Waiting for matching warm public service:',type(e).__name__,flush=True);time.sleep(2)
 record.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),after={p.name:sha(p) for p in [binary,script,config]},status=status,ready=ready)
 (root/'deployment-result.json').write_text(json.dumps(record,indent=2)+'\n')
except BaseException:
 subprocess.run(['systemctl','stop',*services],check=True)
 for p in [binary,config]:replace(backup/p.name,p)
 subprocess.run(['systemctl','start','transparent-publish-controller'],check=True)
 raise
subprocess.run(['systemd-run','--unit=transparent-m1-cancel-prepare-rollout','--property=Restart=no','/usr/bin/python3',str(root/'ops/scripts/run-transparent-hardening-rollout.py'),'--artifacts',str(artifacts),'--source-sha','2c4a2507523a39e76aef8a6db3076c40d54026ae','--observe-installed-canary','--out',str(root/'rollout')],check=True)
print('Matching warm service verified; fresh canary supervisor started.',flush=True)
