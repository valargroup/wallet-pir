import os,subprocess
from pathlib import Path
root=Path('/opt/transparent-publisher-build/defer-collection-20260911')
env=dict(os.environ,CARGO_TARGET_DIR='/opt/transparent-publisher-build/6e0c65c/target',RUSTFLAGS='-C target-cpu=x86-64-v3 -C target-feature=+pclmulqdq',CARGO_BUILD_JOBS='2')
with (root/'linux-integration.log').open('w') as out:
 subprocess.run(['/root/.cargo/bin/cargo','test','--locked','--release','-p','transparent-shard-server','--test','revisions_and_cache','--test','assignment','--','--nocapture'],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
