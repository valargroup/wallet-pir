import asyncio,hashlib,importlib.util,json,stat,time
from pathlib import Path
source=Path('/opt/transparent-publisher-build/sessions-20260910/transparent-live-fleet.forwarding.py')
s=importlib.util.spec_from_file_location('fleet',source);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
async def main():
 root=Path('/run/tp-forward-six');root.mkdir(mode=0o700)
 c=json.loads(Path('/opt/transparent-publisher/fleet.json').read_text())
 c.update(state_dir=str(root),control_sessions=True,status_socket_forwarding=True)
 f=m.Fleet(c);assert len(f.roster)==6
 owner=asyncio.create_task(f.serve_control_sessions())
 async def measure(w):
  deadline=time.monotonic()+15
  while True:
   if owner.done():await owner
   try:
    value=await f.control(w,{'operation':'status'})
    assert value['warm'];break
   except (OSError,RuntimeError,TimeoutError):
    if time.monotonic()>deadline:raise
    await asyncio.sleep(.1)
  assert stat.S_IMODE(f.status_forward_path(w).stat().st_mode)==0o600
  samples=[]
  for _ in range(10):
   start=time.monotonic();value=await f.control(w,{'operation':'status'});samples.append(time.monotonic()-start)
   assert value['warm'] and len(value['active']['map_sha256'])==64
   await asyncio.sleep(.5)
  return {'worker':w['id'],'seconds':samples,'active':value['active']['map_sha256']}
 try:rows=await asyncio.gather(*(measure(w) for w in f.roster))
 finally:
  owner.cancel()
  try:await owner
  except asyncio.CancelledError:pass
 result={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'workers':rows,'scope':'isolated status transport on all six current workers; no live configuration change'}
 Path('/opt/transparent-publisher-build/sessions-20260910/forward-six.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
asyncio.run(main())
