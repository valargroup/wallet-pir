"""Enable the qualified status transport under both existing maintenance guards."""
import asyncio,hashlib,importlib.util,json,shutil,subprocess,time
from pathlib import Path
LIVE=Path('/opt/transparent-publisher');STAGE=Path('/opt/transparent-publisher-build/sessions-20260910')
OLD_SHA='33bccaaef1d57692630a1472860d1db7ca89d4ef2d4e47047924ba40d475f232'
NEW_SHA='b96c007ce76638f829119ab2013308d993cdba5fef76c7a8be2e14b21cf49698'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
U=load('upgrade',LIVE/'upgrade-transparent-fleet.py')
def install(source,target):
 temp=target.with_name(target.name+'.forward-new');shutil.copy2(source,temp);temp.replace(target)
async def main():
 script=LIVE/'transparent-live-fleet.py';config=LIVE/'fleet.json'
 assert sha(script)==OLD_SHA and sha(STAGE/'transparent-live-fleet.forwarding.py')==NEW_SHA
 c=json.loads(config.read_text());assert c.get('control_sessions') and not c.get('status_socket_forwarding')
 proof=json.loads((STAGE/'forward-six.json').read_text());assert proof['source_sha256']==NEW_SHA and len(proof['workers'])==6
 for unit in ['transparent-m1-stall-load','transparent-m1-stall-probe']:
  state=subprocess.check_output(['systemctl','show',unit,'-p','ActiveState','--value'],text=True).strip()
  assert state not in ('active','activating'),unit+' still running'
 running=subprocess.check_output(['systemctl','list-units','--state=running','--no-legend','--plain','transparent*rollout*'],text=True)
 assert not running.strip(),'another acceptance rollout is active'
 saved=STAGE/'before-forward-enable';saved.mkdir(mode=0o700)
 shutil.copy2(script,saved/script.name);shutil.copy2(config,saved/config.name)
 old=U.L.Fleet(c)
 services=('transparent-publish-controller','transparent-replica-reconciler')
 # A failure in entering maintenance leaves the guard state for inspection;
 # no source/config change occurs until both origins attest maintenance.
 await U.maintenance(old,saved)
 try:
  U.service('stop',*services);U.service('stop','transparent-control-sessions')
  install(STAGE/'transparent-live-fleet.forwarding.py',script)
  candidate={**c,'status_socket_forwarding':True};U.L.atomic_json(config,candidate)
  U.service('start','transparent-control-sessions')
  M=load('forwarding_live',script);fleet=M.Fleet(candidate)
  deadline=time.monotonic()+20
  while True:
   try:
    statuses=await asyncio.gather(*(fleet.control(w,{'operation':'status'}) for w in fleet.roster))
    assert all(s.get('warm') and not s.get('invalidated',False) for s in statuses)
    break
   except (OSError,RuntimeError,TimeoutError,AssertionError):
    if time.monotonic()>=deadline:raise
    await asyncio.sleep(.2)
  await U.start_authority()
  await U.reopen(fleet,saved);await U.verify_public(fleet)
  result={'passed':True,'fleet_script_sha256':sha(script),'fleet_config_sha256':sha(config),'source':'eb116e9','all_six_forwarded_statuses_valid':True}
  U.L.atomic_json(STAGE/'forward-enable-result.json',result);print(json.dumps(result),flush=True)
 except BaseException as error:
  # Preserve the current publication; a transport rollback never rewinds it.
  U.service('stop',*services);U.service('stop','transparent-control-sessions')
  U.L.atomic_json(old.root/'maintenance.json',{'enabled':True});await old.route([])
  U.apply_coordinator((saved/'Caddyfile.guarded').read_bytes())
  install(saved/'transparent-live-fleet.py',script);install(saved/'fleet.json',config)
  U.service('start','transparent-control-sessions')
  await U.start_authority()
  reopened=False;recovery=None
  deadline=time.monotonic()+60
  while time.monotonic()<deadline:
   try:
    await U.reopen(old,saved);await U.verify_public(old);reopened=True;break
   except Exception as e:
    recovery=str(e);await asyncio.sleep(1)
  U.L.atomic_json(STAGE/'forward-enable-result.json',{'passed':False,'error':str(error),'rollback_reopened':reopened,'rollback_error':recovery})
  raise
asyncio.run(main())
